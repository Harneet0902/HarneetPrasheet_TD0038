package org.fi.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ShowAllProduct
 */
@WebServlet("/ShowAllProduct")
public class ShowAllProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		 PrintWriter out=	response.getWriter();
			
			out.println("<html>");
			out.println("<body>");
			out.println("<table border='1'>");
			out.println("<tr>");
			//out.println("<th>categoryId</th>");
			out.println("<th>productName</th>");
			//out.println("<th>categoryDescription</th>");
			//out.println("<th>categoryImageUrl</th>");
			out.println("</tr>");
			
			
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
			
				try (
				Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/harneet", "root", "Pspp@0902");
				PreparedStatement psAllCategory = connection.prepareStatement("select productName from products");

				ResultSet result=psAllCategory.executeQuery();)
				{
					out.println("<html><body><table border='1'>");

				while(result.next()) {
					
				out.println("<tr>");
				//out.println("<td>"+result.getString("categoryId")+"</td>");
				out.println("<td>"+result.getString("productName")+"</td>");
				//out.println("<td>"+result.getString("categoryDescription")+"</td>");
				//out.println("<td>"+result.getString("categoryImageUrl")+"</td>");
				}
			 }
			}
			catch(Exception e) {
				e.getLocalizedMessage();
			}
		/**
		 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
		 */

	}
	}


