package org.fi.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DeleteProduct
 */
@WebServlet("/DeleteProduct")
public class DeleteProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		String productId = request.getParameter("productId");		

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			try(Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/harneet", "root", "Pspp@0902");
					PreparedStatement psinsert = connection.prepareStatement("DELETE FROM products WHERE productId=?");
					)
			{
				PrintWriter out= response.getWriter();
				out.println("<html>");
				out.println("<body>");

				psinsert.setString(1, productId);
				


				try
				{
					int result= psinsert.executeUpdate();
					if(result>0)
						response.sendRedirect("ProductDescription");
					else
						response.sendRedirect("login.html");
					out.println("</body>");
					out.println("</html>");
				}
				catch(Exception e) {
					e.printStackTrace();
					System.out.println("e >"+e);
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
		}catch (Exception e) {
			// TODO: handle exception
		}
	}
	}

