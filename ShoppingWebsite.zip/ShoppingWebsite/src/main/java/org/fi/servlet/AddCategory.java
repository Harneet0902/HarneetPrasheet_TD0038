package org.fi.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AddCategory
 */
@WebServlet("/AddCategory")
public class AddCategory extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddCategory() {
        //super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		String categoryId = request.getParameter("categoryId");
		String categoryName = request.getParameter("categoryName");
		String categoryDescription = request.getParameter("categoryDescription");
		String categoryImageUrl = request.getParameter("categoryImageUrl");


		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			try(Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/harneet", "root", "Pspp@0902");
					PreparedStatement psinsert = connection.prepareStatement("insert into category1(categoryId, categoryName, categoryDescription, categoryImageUrl) values (?,?,?,?)");
					)
			{
				PrintWriter out= response.getWriter();
				out.println("<html>");
				out.println("<body>");

				psinsert.setString(1, categoryId);
				psinsert.setString(2, categoryName);
				psinsert.setString(3, categoryDescription);
				psinsert.setString(4, categoryImageUrl);


				try
				{
					int result= psinsert.executeUpdate();
					if(result>0)
						response.sendRedirect("Category");
					else
						response.sendRedirect("login.html");
					out.println("</body>");
					out.println("</html>");
				}
				catch(Exception e) {
					e.printStackTrace();
					System.out.println("e >"+e);
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
		}catch (Exception e) {
			// TODO: handle exception
		}
	}
	}

